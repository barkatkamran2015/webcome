
<?php
	$fname = $_POST['fname'];
    $email = $_POST['email'];
	$gender = $_POST['gender'];
	$phone = $_POST['phone'];
	$area = $_POST['area'];

	// Database connection
	$conn = new mysqli('localhost','root','','test');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into contact(fname, email, gender, phone, area) values(?, ?, ?, ?, ?)");
		$stmt->bind_param("sssis", $fname, $email, $gender, $phone, $area);
		$stmt->execute();
		echo "You Have Registered successfully!";
		$stmt->close();
		$conn->close();
	}
?>

<br><br>
<html>
<head>
	
</head>
	<body>
	<a href="contact.html"><b>Return to the Previous Page</b></a>
	</body>
</html>